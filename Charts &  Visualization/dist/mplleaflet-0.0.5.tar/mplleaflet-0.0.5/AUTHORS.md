mplleaflet is written and maintained by Jacob Wasserman
(https://github.com/jwass) with patches by:

* Marius van Niekerk (https://github.com/mariusvniekerk)
* Filipe Fernandes (https://github.com/ocefpaf)
* Mike Fienen (https://github.com/mnfienen)
* Michelle Fullwood (https://github.com/michelleful)
* Martin Journois (https://github.com/BibMartin)
* Simon Norris (https://github.com/smnorris)
